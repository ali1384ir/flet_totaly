name = "SearchBar"
description = """A Material Design search bar. It visually looks like a TextField with the difference that, tapping on it opens a search view."""
