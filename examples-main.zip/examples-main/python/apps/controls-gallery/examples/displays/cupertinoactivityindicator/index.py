name = "CupertinoActivityIndicator"
description = """An iOS-style activity indicator that spins clockwise."""
