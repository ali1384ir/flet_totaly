name = "Canvas"
description = """Canvas is a control for drawing arbitrary graphics using a set of primitives or "shapes" such as line, arc, path and text."""
