name = "Audio"

description = """A control to simultaneously play multiple audio files. Works on macOS, Linux, Windows, iOS, Android and web. Based on audioplayers Flutter widget.

Audio control is non-visual and should be added to `page.overlay` list."""
