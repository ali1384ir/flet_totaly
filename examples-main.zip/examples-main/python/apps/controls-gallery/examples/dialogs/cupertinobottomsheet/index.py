name = "CupertinoBottomSheet"
description = """An iOS-style bottom sheet."""
