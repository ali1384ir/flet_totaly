name = "CupertinoActionSheet"
description = """An iOS-style action sheet."""
