name = "ExpansionPanelList"
description = """A material expansion panel list that lays out its children and animates expansions."""
