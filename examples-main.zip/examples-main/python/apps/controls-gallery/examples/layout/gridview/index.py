name = "GridView"
description = """A scrollable, 2D array of controls.

GridView is very effective for large lists (thousands of items). Prefer it over wrapping Column or Row for smooth scrolling."""
