name = "Pagelet"
description = (
    """Pagelet implements the basic Material Design visual layout structure."""
)
