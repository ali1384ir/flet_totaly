name = "Tabs"
description = """The Tabs control is used for navigating frequently accessed, distinct content categories. 

Tabs allow for navigation between two or more content views and relies on text headers to articulate the different sections of content."""
