name = "Row"
description = "A control that displays its children in a horizontal array."
