name = "CupertinoActionSheetAction"
description = """An action button typically used in CupertinoActionSheet."""
