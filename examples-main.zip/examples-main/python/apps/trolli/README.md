# flet-trello-clone
A clone of trello built with Flet. 


Live demo [here](https://flet-trolli.fly.dev/)
